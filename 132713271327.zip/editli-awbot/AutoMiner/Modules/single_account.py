# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import time, re
import urllib.parse as urlparse
from win32api import GetSystemMetrics

import configs
from Modules import input, browser, js, datetimeutil, captcha, notification, log


class SingleAccount:
    current_hour = datetimeutil.nowHour()
    mining = 0
    claiming = 0

    def __init__(self, account, index=0):
        self.index = index
        self.cookies = account['cookies']
        self.proxy = account['proxy']
        self.land = account['land']
        self.tools = account['tools']
        self.username = account['username']
        self.browser = None
        self.rc = None
        self.last_activity_time = 0
        self.mines = 0
        self.cpu = 0
        self.net = 0
        self.ram = 0
        self.current_wax = 0
        self.staked_wax = 0
        self.last_tlm = 0
        self.time_to_delay_time = 0
        self.delay_time = 0
        self.status = 0
        self.current_hour = SingleAccount.current_hour

    def init(self):
        self.status = 1
        self.browser = browser.Browser(self.index)
        self.browser.init(self.proxy)
        if configs.enableSolveCaptcha:
            self.rc = captcha.Captcha()
        self.last_activity_time = datetimeutil.nowTimeStamp()

        log.screen_n_file(self.index, '', False)
        log.screen_n_file(self.index, '', False)
        log.screen_n_file(self.index,
                          '-+- -A- -U- -T- -O- -+- -A- -L- -M- -O- -S- -T- -+- -E- -V- -E- -R- -Y- -T- -H- -I- -N- -G- -+-',
                          False)
        log.screen_n_file(self.index, '', False)
        log.screen_n_file(self.index, 'Thread %d starts at %s' % (self.index, datetimeutil.nowDateTime()), False)
        log.screen_n_file(self.index, '', False)

    def restart(self):
        if self.status == 9:
            SingleAccount.mining -= 1
        elif self.status == 10:
            SingleAccount.claiming -= 1
        log.screen_n_file(self.index, self.browser.restartReason)
        try:
            self.browser.quit()
        except:
            pass
        raise Exception('Restart thread %d' % self.index)

    def LogintoWax(self):
        self.status = 2
        self.last_activity_time = datetimeutil.nowTimeStamp()
        log.screen_n_file(self.index, '[+] Logging to WAX...')
        isLoggedIn = False
        try:
            self.browser.get(configs.urlConfig['login'])
            self.browser.setCookies(self.cookies)
            self.browser.get(configs.urlConfig['login'])
            if 'Redirecting you to WAX Cloud Wallet' in self.browser.source() or configs.urlConfig[
                'wallet'] in self.browser.url():
                isLoggedIn = True
                log.screen_n_file(self.index, '[+] Logged-in to WAX.io.')
            else:
                log.screen_n_file(self.index,
                                  '[-] Can not login to WAX.io. Please check your cookies of account index %d in Excel file.' % (
                                          self.index + 1))
                notification.notify(configs.app,
                                    'Can not login to WAX.io. Please check your cookies of account index %d in Excel file.' % (
                                            self.index + 1))
        except Exception as ex:
            log.screen_n_file(self.index, '[!] %s has exception: %s!' % (configs.app, ex))
            notification.notify(configs.app, '%s has exception: %s!' % (configs.app, ex))
        self.last_activity_time = datetimeutil.nowTimeStamp()

        return isLoggedIn

    def SetLand(self):
        self.status = 6
        self.last_activity_time = datetimeutil.nowTimeStamp()
        log.screen_n_file(self.index, '[+] Setting land...')
        backWindow = self.browser.window()
        isSuccess = False
        try:
            self.browser.newWindow(configs.urlConfig['bloks'])
            self.browser.switchWindow_Path(configs.urlConfig['bloks'])
            time.sleep(10)
            wc = self.browser.windowsCount()
            backWindow2 = self.browser.window()
            self.browser.browser.find_element_by_xpath(
                "//input[contains(@placeholder, 'Search by Block # / Account / Public Key / TX ID')]").send_keys(
                'm.federation')
            time.sleep(10)
            self.browser.browser.find_elements_by_xpath(
                "//div[contains(@class, 'eight wide mobile three wide tablet three wide computer column flex-container account-tab')]")[
                1].click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//div[contains(text(), 'Actions')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//span[contains(text(), 'setland')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath(
                "//input[contains(@placeholder, 'Enter account name')]").send_keys(
                self.username)
            self.browser.browser.find_element_by_xpath("//input[contains(@placeholder, 'Enter number')]").send_keys(
                self.land)
            self.browser.browser.find_element_by_xpath("//button[contains(@id, 'push-transaction-btn')]").click()
            time.sleep(2)
            if 'Cloud Wallet' in self.browser.source():
                self.browser.browser.find_element_by_xpath("//div[contains(text(), 'Cloud Wallet')]").click()
                time.sleep(10)
                if self.browser.windowsCount() > wc:
                    self.browser.switchWindow_Path(configs.urlConfig['login'])
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                    self.browser.switchWindow(backWindow2)
                self.browser.browser.find_element_by_xpath(
                    "//button[contains(@id, 'push-transaction-btn')]").click()
                time.sleep(10)
            else:
                time.sleep(8)

            # Sign to transaction
            if self.browser.windowsCount() > wc:
                log.screen_n_file(self.index, '[+] Start to sign transaction.')
                self.browser.switchWindow_Path(configs.urlConfig['login'])
                if configs.enableSolveCaptcha:
                    log.screen_n_file(self.index, '  [+] Automatically solve captcha.')
                    while not self.browser.restart:
                        time.sleep(0.2)
                        try:
                            recaptcha = self.browser.browser.find_element_by_xpath(
                                "//iframe[contains(@title, 'reCAPTCHA')]")
                            sitekey = ''
                            for query in urlparse.urlparse(recaptcha.get_attribute('src')).query.split('&'):
                                if 'k=' in str(query):
                                    sitekey = str(query).split('=')[1]
                            token = self.rc.reCaptcha(sitekey, self.browser.url())
                            if token != 'Expired':
                                log.screen_n_file(self.index,
                                                  '    [+] Captcha response is %s.' % (token[:7] + '...' + token[-7:]))
                                self.browser.runJS(js.reCaptchaCallbackFunction % token)
                                startApproval = datetimeutil.nowTimeStamp()
                                while not self.browser.restart and self.browser.windowsCount() > wc:
                                    try:
                                        self.browser.browser.find_element_by_xpath(
                                            "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                        time.sleep(2)
                                    except:
                                        pass
                                    finally:
                                        if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                            startApproval = datetimeutil.nowTimeStamp()
                                            self.browser.refresh()
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                                time.sleep(8)
                                break
                            else:
                                self.browser.runJS(js.reCaptchaReset)
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                else:
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                self.browser.switchWindow(backWindow2)

            if self.browser.windowsCount() == wc:
                if 'Your action was successfully pushed' in self.browser.source():
                    isSuccess = True
        except Exception as ex:
            log.screen_n_file(self.index, '[!] %s has exception: %s!' % (configs.app, ex))
            notification.notify(configs.app, '%s has exception: %s!' % (configs.app, ex))
        finally:
            self.browser.close()
        self.browser.switchWindow(backWindow)
        self.last_activity_time = datetimeutil.nowTimeStamp()

        return isSuccess

    def SetTools(self):
        self.status = 7
        self.last_activity_time = datetimeutil.nowTimeStamp()
        log.screen_n_file(self.index, '  [+] Setting bag...')
        backWindow = self.browser.window()
        isSuccess = False
        try:
            self.browser.newWindow(configs.urlConfig['bloks'])
            self.browser.switchWindow_Path(configs.urlConfig['bloks'])
            time.sleep(10)
            wc = self.browser.windowsCount()
            backWindow2 = self.browser.window()
            self.browser.browser.find_element_by_xpath(
                "//input[contains(@placeholder, 'Search by Block # / Account / Public Key / TX ID')]").send_keys(
                'm.federation')
            time.sleep(10)
            self.browser.browser.find_elements_by_xpath(
                "//div[contains(@class, 'eight wide mobile three wide tablet three wide computer column flex-container account-tab')]")[
                1].click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//div[contains(text(), 'Actions')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//span[contains(text(), 'setbag')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath(
                "//input[contains(@placeholder, 'Enter account name')]").send_keys(
                self.username)
            self.browser.browser.find_element_by_xpath("//input[contains(@placeholder, 'Enter uint64[]')]").send_keys(
                '["' + '","'.join(self.tools) + '"]')
            self.browser.browser.find_element_by_xpath("//button[contains(@id, 'push-transaction-btn')]").click()
            time.sleep(2)
            if 'Cloud Wallet' in self.browser.source():
                self.browser.browser.find_element_by_xpath("//div[contains(text(), 'Cloud Wallet')]").click()
                time.sleep(10)
                if self.browser.windowsCount() > wc:
                    self.browser.switchWindow_Path(configs.urlConfig['login'])
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                    self.browser.switchWindow(backWindow2)
                self.browser.browser.find_element_by_xpath(
                    "//button[contains(@id, 'push-transaction-btn')]").click()
                time.sleep(10)
            else:
                time.sleep(8)

            # Sign to transaction
            if self.browser.windowsCount() > wc:
                log.screen_n_file(self.index, '  [+] Start to sign transaction.')
                self.browser.switchWindow_Path(configs.urlConfig['login'])
                if configs.enableSolveCaptcha:
                    log.screen_n_file(self.index, '  [+] Automatically solve captcha.')
                    while not self.browser.restart:
                        try:
                            time.sleep(0.2)
                            recaptcha = self.browser.browser.find_element_by_xpath(
                                "//iframe[contains(@title, 'reCAPTCHA')]")
                            sitekey = ''
                            for query in urlparse.urlparse(recaptcha.get_attribute('src')).query.split('&'):
                                if 'k=' in str(query):
                                    sitekey = str(query).split('=')[1]
                            token = self.rc.reCaptcha(sitekey, self.browser.url())
                            if token != 'Expired':
                                log.screen_n_file(self.index,
                                                  '    [+] Captcha response is %s.' % (token[:7] + '...' + token[-7:]))
                                self.browser.runJS(js.reCaptchaCallbackFunction % token)
                                startApproval = datetimeutil.nowTimeStamp()
                                while not self.browser.restart and self.browser.windowsCount() > wc:
                                    try:
                                        self.browser.browser.find_element_by_xpath(
                                            "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                        time.sleep(2)
                                    except:
                                        pass
                                    finally:
                                        if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                            startApproval = datetimeutil.nowTimeStamp()
                                            self.browser.refresh()
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                                time.sleep(8)
                                break
                            else:
                                self.browser.runJS(js.reCaptchaReset)
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                else:
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                self.browser.switchWindow(backWindow2)

            if self.browser.windowsCount() == wc:
                if 'Your action was successfully pushed' in self.browser.source():
                    isSuccess = True
        except Exception as ex:
            log.screen_n_file(self.index, '[!] %s has exception: %s!' % (configs.app, ex))
            notification.notify(configs.app, '%s has exception: %s!' % (configs.app, ex))
        finally:
            self.browser.close()
        self.browser.switchWindow(backWindow)
        self.last_activity_time = datetimeutil.nowTimeStamp()

        return isSuccess

    def StakeWAX(self):
        self.status = 14
        self.last_activity_time = datetimeutil.nowTimeStamp()
        log.screen_n_file(self.index, '  [+] Staking WAX...')
        backWindow = self.browser.window()
        isSuccess = False
        try:
            self.browser.newWindow(configs.urlConfig['wallet'])
            self.browser.switchWindow_Path(configs.urlConfig['wallet'])
            time.sleep(10)
            wc = self.browser.windowsCount()
            self.browser.browser.find_element_by_xpath("//div[contains(@class, 'open-right')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//button[contains(text(), 'Resources')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//input[contains(@placeholder, 'Amount Of WAXP')]").send_keys(
                str(configs.amountStakeWAX))
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//button[contains(text(), 'Stake')]").click()
            time.sleep(10)

            # Sign to transaction
            if self.browser.windowsCount() > wc:
                log.screen_n_file(self.index, '    [+] Start to sign transaction.')
                backWindow2 = self.browser.window()
                self.browser.switchWindow_Path(configs.urlConfig['login'])
                if configs.enableSolveCaptcha:
                    log.screen_n_file(self.index, '      [+] Automatically solve captcha.')
                    while not self.browser.restart:
                        try:
                            time.sleep(0.2)
                            recaptcha = self.browser.browser.find_element_by_xpath(
                                "//iframe[contains(@title, 'reCAPTCHA')]")
                            sitekey = ''
                            for query in urlparse.urlparse(recaptcha.get_attribute('src')).query.split('&'):
                                if 'k=' in str(query):
                                    sitekey = str(query).split('=')[1]
                            token = self.rc.reCaptcha(sitekey, self.browser.url())
                            if token != 'Expired':
                                log.screen_n_file(self.index,
                                                  '        [+] Captcha response is %s.' % (
                                                          token[:7] + '...' + token[-7:]))
                                self.browser.runJS(js.reCaptchaCallbackFunction % token)
                                startApproval = datetimeutil.nowTimeStamp()
                                while not self.browser.restart and self.browser.windowsCount() > wc:
                                    try:
                                        self.browser.browser.find_element_by_xpath(
                                            "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                        time.sleep(2)
                                    except:
                                        pass
                                    finally:
                                        if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                            startApproval = datetimeutil.nowTimeStamp()
                                            self.browser.refresh()
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                                time.sleep(8)
                                break
                            else:
                                self.browser.runJS(js.reCaptchaReset)
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                else:
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                self.browser.switchWindow(backWindow2)

            if self.browser.windowsCount() == wc:
                if 'Transaction Success' in self.browser.source():
                    isSuccess = True
        except Exception as ex:
            log.screen_n_file(self.index, '[!] %s has exception: %s!' % (configs.app, ex))
            notification.notify(configs.app, '%s has exception: %s!' % (configs.app, ex))
        finally:
            self.browser.close()
        self.browser.switchWindow(backWindow)
        self.last_activity_time = datetimeutil.nowTimeStamp()

        return isSuccess

    def ClaimNFTs(self):
        self.status = 15
        self.last_activity_time = datetimeutil.nowTimeStamp()
        log.screen_n_file(self.index, '  [+] Claiming NFTs...')
        backWindow = self.browser.window()
        isSuccess = False
        try:
            self.browser.newWindow(configs.urlConfig['bloks'])
            self.browser.switchWindow_Path(configs.urlConfig['bloks'])
            time.sleep(10)
            wc = self.browser.windowsCount()
            backWindow2 = self.browser.window()
            self.browser.browser.find_element_by_xpath(
                "//input[contains(@placeholder, 'Search by Block # / Account / Public Key / TX ID')]").send_keys(
                'm.federation')
            time.sleep(10)
            self.browser.browser.find_elements_by_xpath(
                "//div[contains(@class, 'eight wide mobile three wide tablet three wide computer column flex-container account-tab')]")[
                1].click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//div[contains(text(), 'Actions')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath("//span[contains(text(), 'claimnfts')]").click()
            time.sleep(2)
            self.browser.browser.find_element_by_xpath(
                "//input[contains(@placeholder, 'Enter account name')]").send_keys(
                self.username)
            self.browser.browser.find_element_by_xpath("//button[contains(@id, 'push-transaction-btn')]").click()
            time.sleep(2)
            if 'Cloud Wallet' in self.browser.source():
                self.browser.browser.find_element_by_xpath("//div[contains(text(), 'Cloud Wallet')]").click()
                time.sleep(10)
                if self.browser.windowsCount() > wc:
                    self.browser.switchWindow_Path(configs.urlConfig['login'])
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                    self.browser.switchWindow(backWindow2)
                self.browser.browser.find_element_by_xpath(
                    "//button[contains(@id, 'push-transaction-btn')]").click()
                time.sleep(10)
            else:
                time.sleep(8)

            # Sign to transaction
            if self.browser.windowsCount() > wc:
                log.screen_n_file(self.index, '  [+] Start to sign transaction.')
                self.browser.switchWindow_Path(configs.urlConfig['login'])
                if configs.enableSolveCaptcha:
                    log.screen_n_file(self.index, '    [+] Automatically solve captcha.')
                    while not self.browser.restart:
                        time.sleep(0.2)
                        try:
                            recaptcha = self.browser.browser.find_element_by_xpath(
                                "//iframe[contains(@title, 'reCAPTCHA')]")
                            sitekey = ''
                            for query in urlparse.urlparse(recaptcha.get_attribute('src')).query.split('&'):
                                if 'k=' in str(query):
                                    sitekey = str(query).split('=')[1]
                            token = self.rc.reCaptcha(sitekey, self.browser.url())
                            if token != 'Expired':
                                log.screen_n_file(self.index,
                                                  '      [+] Captcha response is %s.' % (
                                                          token[:7] + '...' + token[-7:]))
                                self.browser.runJS(js.reCaptchaCallbackFunction % token)
                                startApproval = datetimeutil.nowTimeStamp()
                                while not self.browser.restart and self.browser.windowsCount() > wc:
                                    try:
                                        self.browser.browser.find_element_by_xpath(
                                            "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                        time.sleep(2)
                                    except:
                                        pass
                                    finally:
                                        if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                            startApproval = datetimeutil.nowTimeStamp()
                                            self.browser.refresh()
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                                time.sleep(8)
                                break
                            else:
                                self.browser.runJS(js.reCaptchaReset)
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                else:
                    startApproval = datetimeutil.nowTimeStamp()
                    while not self.browser.restart and self.browser.windowsCount() > wc:
                        try:
                            self.browser.browser.find_element_by_xpath(
                                "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                            time.sleep(2)
                        except:
                            pass
                        finally:
                            if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                startApproval = datetimeutil.nowTimeStamp()
                                self.browser.refresh()
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(8)
                self.browser.switchWindow(backWindow2)

            if self.browser.windowsCount() == wc:
                if 'Your action was successfully pushed' in self.browser.source():
                    isSuccess = True
        except Exception as ex:
            log.screen_n_file(self.index, '[!] %s has exception: %s!' % (configs.app, ex))
            notification.notify(configs.app, '%s has exception: %s!' % (configs.app, ex))
        finally:
            self.browser.close()
        self.browser.switchWindow(backWindow)
        self.last_activity_time = datetimeutil.nowTimeStamp()

        return isSuccess

    def AutoMiner(self):
        func = 'Auto Mine, Claim TLM and Sign Transaction'

        lastDoSetLand = 0
        lastDoSetTools = 0
        try:
            # Initial
            self.init()

            px = self.index * configs.distanceBw2BrowserX
            py = 0
            if px > GetSystemMetrics(0) - 900:
                px = self.index % int(
                    (GetSystemMetrics(0) - 900) / configs.distanceBw2BrowserX + 1) * configs.distanceBw2BrowserX
                py = int(self.index / int(
                    (GetSystemMetrics(0) - 900) / configs.distanceBw2BrowserX) + 1) * configs.distanceBw2BrowserY
            self.browser.start(px, py)
            wc = self.browser.windowsCount()
            mainWindow = self.browser.window()

            # Login to WAX
            if self.LogintoWax():
                # Login to AlienWorlds
                self.status = 3
                self.last_activity_time = datetimeutil.nowTimeStamp()
                time_to_get_cooldown = 0
                cooldown = 0
                self.browser.get(configs.urlConfig['game'])
                if self.browser.getBrowserName() == "Brave":
                    while not self.browser.restart:
                        try:
                            time.sleep(0.2)
                            self.browser.drawCanvas(0, 93, 0.2)  # Click to Login button
                            if self.browser.windowsCount() > wc:
                                self.browser.switchWindow_Path(configs.urlConfig['login'])
                                break
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    time.sleep(2)

                    if self.browser.windowsCount() > wc:
                        startApproval = datetimeutil.nowTimeStamp()
                        while not self.browser.restart and self.browser.windowsCount() > wc:
                            try:
                                self.browser.browser.find_element_by_xpath(
                                    "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                time.sleep(2)
                            except:
                                pass
                            finally:
                                if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                    startApproval = datetimeutil.nowTimeStamp()
                                    self.browser.refresh()
                        if self.browser.restart:
                            quit()
                        else:
                            self.last_activity_time = datetimeutil.nowTimeStamp()
                        time.sleep(8)

                    self.browser.switchWindow(mainWindow)
                    countFailtoFetch = 0
                    countLengthErr = 0
                    countSysmbolErr = 0
                    while not self.browser.restart:
                        try:
                            time.sleep(0.2)
                            _logs = self.browser.log()
                            isLoggedIn = False
                            for _log in _logs:
                                if 'until next mine' in _log:
                                    try:
                                        time_to_get_cooldown = datetimeutil.nowTimeStamp()
                                        cooldown = int(float(input.santi(
                                            re.findall(r'until next mine .*', _log)[-1].replace(
                                                'until next mine ', ''))) / 1000)
                                    except:
                                        pass
                                if self.username == '' and 'has Logged' in _log:
                                    try:
                                        self.username = re.findall(r'- .* has Logged', _log)[-1].replace(
                                            '- ', '').replace(' has Logged', '')
                                    except:
                                        pass
                                if 'Loaded HomeScene' in _log:
                                    time.sleep(5)
                                    isLoggedIn = True
                                    break
                                elif 'Failed to fetch' in _log:
                                    if str(_log).count('Failed to fetch') > countFailtoFetch:
                                        countFailtoFetch += 1
                                        time.sleep(5)
                                        log.screen_n_file(self.index, '[*] Handing fail to fetch error...')
                                        self.browser.drawCanvas(210, -125)
                                        self.browser.drawCanvas(0, 93)
                                elif 'Cannot read property \'length\' of undefined' in _log:
                                    if str(_log).count('Cannot read property \'length\' of undefined') > countLengthErr:
                                        countLengthErr += 1
                                        time.sleep(5)
                                        log.screen_n_file(self.index, '[*] Handing length error...')
                                        self.browser.drawCanvas(210, -125)
                                        self.browser.drawCanvas(0, 93)
                                elif 'Cannot read property \'Symbol(Symbol.asyncIterator)\' of undefined' in _log:
                                    if str(_log).count('Cannot read property \'Symbol(Symbol.asyncIterator)\' of undefined') > countSysmbolErr:
                                        countSysmbolErr += 1
                                        time.sleep(5)
                                        log.screen_n_file(self.index, '[*] Handing Symbol error...')
                                        self.browser.drawCanvas(210, -125)
                                        self.browser.drawCanvas(0, 93)
                            if isLoggedIn:
                                break
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                else:
                    while not self.browser.restart:
                        try:
                            time.sleep(0.2)
                            _logs = self.browser.log()
                            isClickedLogin = False
                            for _log in _logs:
                                if 'subscribed for account:' in _log:
                                    isClickedLogin = True
                                    break
                            if isClickedLogin:
                                break
                            self.browser.drawCanvas(0, 93)  # Click to Login button
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()

                    countFailtoFetch = 0
                    countLengthErr = 0
                    countSysmbolErr = 0
                    while not self.browser.restart:
                        try:
                            time.sleep(0.2)
                            _logs = self.browser.log()
                            isLoggedIn = False
                            for _log in _logs:
                                if 'until next mine' in _log:
                                    try:
                                        time_to_get_cooldown = datetimeutil.nowTimeStamp()
                                        cooldown = int(float(input.santi(
                                            re.findall(r'until next mine .*', _log)[-1].replace(
                                                'until next mine ', ''))) / 1000)
                                    except:
                                        pass
                                if self.username == '' and 'has Logged' in _log:
                                    try:
                                        self.username = re.findall(r'- .* has Logged', _log)[-1].replace(
                                            '- ', '').replace(' has Logged', '')
                                    except:
                                        pass
                                if 'Loaded HomeScene' in _log:
                                    time.sleep(5)
                                    isLoggedIn = True
                                    break
                                elif 'Failed to fetch' in _log:
                                    if str(_log).count('Failed to fetch') > countFailtoFetch:
                                        countFailtoFetch += 1
                                        time.sleep(5)
                                        log.screen_n_file(self.index, '[*] Handing fail to fetch error...')
                                        self.browser.drawCanvas(210, -125)
                                        self.browser.drawCanvas(0, 93)
                                elif 'Cannot read property \'length\' of undefined' in _log:
                                    if str(_log).count('Cannot read property \'length\' of undefined') > countLengthErr:
                                        countLengthErr += 1
                                        time.sleep(5)
                                        log.screen_n_file(self.index, '[*] Handing length error...')
                                        self.browser.drawCanvas(210, -125)
                                        self.browser.drawCanvas(0, 93)
                                elif 'Cannot read property \'Symbol(Symbol.asyncIterator)\' of undefined' in _log:
                                    if str(_log).count('Cannot read property \'Symbol(Symbol.asyncIterator)\' of undefined') > countSysmbolErr:
                                        countSysmbolErr += 1
                                        time.sleep(5)
                                        log.screen_n_file(self.index, '[*] Handing Symbol error...')
                                        self.browser.drawCanvas(210, -125)
                                        self.browser.drawCanvas(0, 93)
                            if isLoggedIn:
                                break
                        except:
                            pass
                    if self.browser.restart:
                        quit()
                    else:
                        self.last_activity_time = datetimeutil.nowTimeStamp()

                log.screen_n_file(self.index, '[+] %s logged-in to AlienWorlds.' % self.username)
                cooldown -= datetimeutil.nowTimeStamp() - time_to_get_cooldown
                if cooldown > 0:
                    self.last_activity_time = datetimeutil.nowTimeStamp()
                    self.browser.minimize()
                    log.screen_n_file(self.index, '[+] Waiting for cooling down %s...' % (
                        datetimeutil.secondtoMinute(cooldown)))
                    for i in range(int(cooldown) + 1):
                        self.browser.minimize()
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                    self.browser.restore()

                # Mine, Claim, Sign
                lastCheckAssetTime = 0
                while not self.browser.restart:
                    self.last_activity_time = datetimeutil.nowTimeStamp()
                    log.screen_n_file(self.index, '', False)
                    log.screen_n_file(self.index, func.upper())
                    self.browser.restore()

                    # Get resource information
                    self.last_activity_time = datetimeutil.nowTimeStamp()
                    if configs.enableCheckResource:
                        while not self.browser.restart:
                            try:
                                self.status = 4
                                res = self.browser.runJS_Return(js.getResInfo % self.username).split(',')
                                if res != '':
                                    self.cpu = int(float(res[0]))
                                    self.net = int(float(res[1]))
                                else:
                                    self.cpu = 0
                                    self.net = 0
                                log.screen_n_file(self.index,
                                                  '  [+] Get resource information:\n   CPU: %d%%\n   NET: %d%%' % (
                                                      self.cpu, self.net))
                                break
                            except:
                                pass
                        if self.browser.restart:
                            quit()
                        else:
                            self.last_activity_time = datetimeutil.nowTimeStamp()

                    # Get assets information
                    self.last_activity_time = datetimeutil.nowTimeStamp()
                    if configs.enableCheckAssets and datetimeutil.nowTimeStamp() > lastCheckAssetTime + configs.delayCheckAssets:
                        self.status = 5
                        assets = self.browser.runJS_Return(js.getAssetsInfo % self.username).split(',')
                        doSetLandTools = False

                        # Land
                        if configs.enableAutoSetLand:
                            self.last_activity_time = datetimeutil.nowTimeStamp()
                            # Check if land is changed
                            current_land = assets[0]
                            log.screen_n_file(self.index, '  [+] Get current land: %s' % current_land)
                            if self.land == '':
                                self.land = current_land
                            else:
                                # Set land if is changed.
                                if self.land != current_land and datetimeutil.nowTimeStamp() > lastDoSetLand + configs.delaySetLand:
                                    log.screen_n_file(self.index,
                                                      '  [-] Land is changed from %s to %s!' % (
                                                          self.land, current_land))
                                    if self.SetLand():
                                        log.screen_n_file(self.index, '  [+] Set land successfully.')
                                        doSetLandTools = True
                                    else:
                                        log.screen_n_file(self.index, '  [-] Fail to set land.')
                                        lastDoSetLand = datetimeutil.nowTimeStamp()

                        # Tools
                        if configs.enableAutoSetTools:
                            self.last_activity_time = datetimeutil.nowTimeStamp()
                            # Check if tools are dropped
                            current_tools = assets[1][1:-2].split('.')
                            current_tools = [x for x in current_tools if x != '']
                            log.screen_n_file(self.index,
                                              '  [+] Get current tools: %s' % (', '.join(current_tools)))
                            if len(self.tools) == 0:
                                self.tools = current_tools
                            else:
                                # Set tools if is changed
                                if len(self.tools) != len(
                                        current_tools) and datetimeutil.nowTimeStamp() > lastDoSetTools + configs.delaySetTools:
                                    log.screen_n_file(self.index, '  [-] Tools are dropped!')
                                    if self.SetTools():
                                        log.screen_n_file(self.index, '  [+] Set tools successfully.')
                                        doSetLandTools = True
                                    else:
                                        log.screen_n_file(self.index, '  [-] Fail to set tools.')
                                        lastDoSetTools = datetimeutil.nowTimeStamp()

                        if doSetLandTools:
                            log.screen_n_file(self.index,
                                              '  [+] Set land or tools. Wait for %s then restart.' % (
                                                  datetimeutil.secondtoMinute(
                                                      self.delay_time)))
                            self.status = 13
                            self.browser.restart = True
                            self.browser.restartReason = 'Set land or tools. Restart thread now!'
                            self.browser.minimize()
                            time.sleep(10)

                        lastCheckAssetTime = datetimeutil.nowTimeStamp()
                        self.browser.switchWindow(mainWindow)

                    # Mine
                    if self.cpu < 100 and self.net < 100 and self.ram < 100:
                        self.status = 8
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                        isTransactionExpired = False
                        countTransactionExpired = 0

                        self.browser.minimize()
                        overMaxMineAccountAt1TimeFirstTimeNotify = True
                        while not self.browser.restart:
                            try:
                                time.sleep(0.2)
                                if SingleAccount.mining < configs.maxMineAccountAt1Time:
                                    self.status = 9
                                    SingleAccount.mining += 1
                                    self.browser.restore()
                                    break
                                elif overMaxMineAccountAt1TimeFirstTimeNotify:
                                    log.screen_n_file(self.index,
                                                      '  [+] Only %d accounts which can go to Mine phase. Waiting for free slot.' % configs.maxMineAccountAt1Time)
                                    overMaxMineAccountAt1TimeFirstTimeNotify = False
                            except:
                                pass
                        if self.browser.restart:
                            quit()
                        else:
                            self.last_activity_time = datetimeutil.nowTimeStamp()

                        while not self.browser.restart:
                            if not isTransactionExpired:
                                # Mining
                                log.screen_n_file(self.index, '  [+] Start to mine TLM.')
                                self.browser.switchWindow(mainWindow)
                                self.browser.drawCanvas(270, -100, 5)  # Click to Mine button
                                self.browser.drawCanvas(0, 190, 5)  # Click to Mine button

                                self.browser.minimize()
                                log.screen_n_file(self.index, '  [+] Mining...')
                                time.sleep(15)
                                overMaxClaimAccountAt1TimeFirstTimeNotify = True
                                while not self.browser.restart:
                                    try:
                                        time.sleep(0.2)
                                        if SingleAccount.claiming < configs.maxClaimAccountAt1Time:
                                            self.status = 10
                                            SingleAccount.mining -= 1
                                            SingleAccount.claiming += 1
                                            self.browser.restore()
                                            break
                                        elif overMaxClaimAccountAt1TimeFirstTimeNotify:
                                            log.screen_n_file(self.index,
                                                              '  [+] Only %d accounts which can go to Claim phase. Waiting for free slot.' % configs.maxClaimAccountAt1Time)
                                            overMaxClaimAccountAt1TimeFirstTimeNotify = False
                                    except:
                                        pass
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()

                                # Claiming
                                log.screen_n_file(self.index, '  [+] Claiming...')
                                while not self.browser.restart:
                                    try:
                                        time.sleep(0.2)
                                        self.browser.switchWindow(mainWindow)
                                        self.browser.drawCanvas(0, 50)  # Click to Claim button if 1 button
                                        self.browser.drawCanvas(-70,
                                                                60)  # Click to Claim button if 2 buttons, included Change Land button.
                                        self.browser.drawCanvas(300, -200)  # Click to Close button
                                        self.browser.drawCanvas(0, 190, 5)  # Click to Mine button
                                        if self.browser.windowsCount() > wc:
                                            break
                                    except:
                                        pass
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()

                            isTransactionExpired = False

                            # Signing
                            self.browser.switchWindow_Path(configs.urlConfig['login'])
                            if configs.enableSolveCaptcha:
                                log.screen_n_file(self.index, '  [+] Automatically solve captcha.')
                                tryTime = configs.solveCaptchaConfig['reTry']  # Retry n times if captcha is expired
                                while not self.browser.restart:
                                    try:
                                        time.sleep(0.2)
                                        if self.browser.windowsCount() > wc:
                                            recaptcha = self.browser.browser.find_element_by_xpath(
                                                "//iframe[contains(@title, 'reCAPTCHA')]")
                                            sitekey = ''
                                            for query in urlparse.urlparse(recaptcha.get_attribute('src')).query.split(
                                                    '&'):
                                                if 'k=' in str(query):
                                                    sitekey = str(query).split('=')[1]
                                            token = self.rc.reCaptcha(sitekey, self.browser.url())
                                            if token != 'Expired':
                                                log.screen_n_file(self.index, '    [+] Captcha response is %s.' % (
                                                        token[:7] + '...' + token[-7:]))

                                                # Run callback function
                                                self.browser.runJS(js.reCaptchaCallbackFunction % token)
                                                startApproval = datetimeutil.nowTimeStamp()
                                                while not self.browser.restart and self.browser.windowsCount() > wc:
                                                    try:
                                                        self.browser.browser.find_element_by_xpath(
                                                            "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                                        time.sleep(2)
                                                    except:
                                                        pass
                                                    finally:
                                                        if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                                            startApproval = datetimeutil.nowTimeStamp()
                                                            self.browser.refresh()
                                                if self.browser.restart:
                                                    quit()
                                                else:
                                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                                                time.sleep(8)
                                                self.browser.switchWindow(mainWindow)

                                                self.browser.drawCanvas(215, -120, 2)  # Click to Close button
                                                self.browser.drawCanvas(0, 50)  # Click to Claim button if 1 button
                                                self.browser.drawCanvas(-70,
                                                                        60)  # Click to Claim button if 2 buttons, included Change Land button.
                                                time.sleep(10)
                                                if self.browser.windowsCount() > wc:
                                                    isTransactionExpired = True
                                                    countTransactionExpired += 1
                                                    if countTransactionExpired >= 3:
                                                        if configs.enableStakeWAX:
                                                            wax = self.browser.runJS_Return(
                                                                js.getStakedWAX % self.username).split(',')
                                                            try:
                                                                self.staked_wax = float(wax[0])
                                                            except:
                                                                self.staked_wax = 0
                                                            try:
                                                                self.available_wax = float(wax[1])
                                                            except:
                                                                self.available_wax = 0
                                                            if self.available_wax >= configs.amountStakeWAX and self.staked_wax < configs.maxAmountStakeWAX:
                                                                log.screen_n_file(self.index,
                                                                                  '  [-] Transaction is expired in multi-time and/or out of resource. Try to stake more WAX.')
                                                                if self.StakeWAX():
                                                                    log.screen_n_file(self.index,
                                                                                      '  [+] Staked %f WAX successfully. Current staked WAX is %f.' % (
                                                                                          configs.amountStakeWAX,
                                                                                          self.staked_wax))
                                                                    countTransactionExpired -= 1
                                                                    isTransactionExpired = True
                                                                    self.browser.switchWindow_Path(
                                                                        configs.urlConfig['login'])
                                                                else:
                                                                    log.screen_n_file(self.index,
                                                                                      '  [-] Fail to stake WAX. Wait for %s then restart.' % (
                                                                                          datetimeutil.secondtoMinute(
                                                                                              configs.delayOutofCPU)))
                                                                    SingleAccount.claiming -= 1
                                                                    self.status = 12
                                                                    for i in range(configs.delayOutofCPU):
                                                                        self.browser.minimize()
                                                                        self.last_activity_time = datetimeutil.nowTimeStamp()
                                                                    self.status = 13
                                                                    self.browser.restart = True
                                                                    self.browser.restartReason = 'Transaction is expired in multi-time and/or out of resource. Restart thread now!'
                                                                    self.browser.minimize()
                                                                    time.sleep(10)
                                                            else:
                                                                log.screen_n_file(self.index,
                                                                                  '  [-] Transaction is expired in multi-time and/or out of resource. Want to stake WAX but can not do now. Wait for %s then restart.' % (
                                                                                      datetimeutil.secondtoMinute(
                                                                                          configs.delayOutofCPU)))
                                                                SingleAccount.claiming -= 1
                                                                self.status = 12
                                                                for i in range(configs.delayOutofCPU):
                                                                    self.browser.minimize()
                                                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                                                                self.status = 13
                                                                self.browser.restart = True
                                                                self.browser.restartReason = 'Transaction is expired in multi-time and/or out of resource. Restart thread now!'
                                                                self.browser.minimize()
                                                                time.sleep(10)
                                                        else:
                                                            log.screen_n_file(self.index,
                                                                              '  [-] Transaction is expired in multi-time and/or out of resource. Wait for %s then restart.' % (
                                                                                  datetimeutil.secondtoMinute(
                                                                                      configs.delayOutofCPU)))
                                                            SingleAccount.claiming -= 1
                                                            self.status = 12
                                                            for i in range(configs.delayOutofCPU):
                                                                self.browser.minimize()
                                                                self.last_activity_time = datetimeutil.nowTimeStamp()
                                                            self.status = 13
                                                            self.browser.restart = True
                                                            self.browser.restartReason = 'Transaction is expired in multi-time and/or out of resource. Restart thread now!'
                                                            self.browser.minimize()
                                                            time.sleep(10)
                                                    else:
                                                        isTransactionExpired = True
                                                        self.browser.switchWindow_Path(configs.urlConfig['login'])
                                                        log.screen_n_file(self.index,
                                                                          '  [-] Transaction is expired and/or Out of CPU.')
                                                break
                                            else:
                                                # Try to solve captcha again
                                                self.browser.runJS(js.reCaptchaReset)
                                                tryTime -= 1
                                                log.screen_n_file(self.index,
                                                                  '    [-] Captcha is expired! %d times left to try.' % tryTime)
                                                if tryTime <= 0:
                                                    log.screen_n_file(self.index,
                                                                      '  [-] Captcha is expired in multi-time. Anti-captcha service is not stable now. Wait for %s then restart.' % (
                                                                          datetimeutil.secondtoMinute(
                                                                              configs.delayCaptchaExpiredMultiTime)))
                                                    SingleAccount.claiming -= 1
                                                    self.status = 12
                                                    for i in range(configs.delayCaptchaExpiredMultiTime):
                                                        self.browser.minimize()
                                                        self.last_activity_time = datetimeutil.nowTimeStamp()
                                                    self.status = 13
                                                    self.browser.restart = True
                                                    self.browser.restartReason = 'Captcha is expired in multi-time. Restart thread now!'
                                                    self.browser.minimize()
                                                    time.sleep(10)
                                    except:
                                        pass
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                            else:
                                while not self.browser.restart:
                                    try:
                                        time.sleep(0.2)
                                        startApproval = datetimeutil.nowTimeStamp()
                                        while not self.browser.restart and self.browser.windowsCount() > wc:
                                            try:
                                                self.browser.browser.find_element_by_xpath(
                                                    "//button[contains(@class, 'button button-secondary button-large text-1-5rem text-bold mx-1')]").click()
                                                time.sleep(2)
                                            except:
                                                pass
                                            finally:
                                                if self.browser.windowsCount() > wc and datetimeutil.nowTimeStamp() > startApproval + 30:
                                                    startApproval = datetimeutil.nowTimeStamp()
                                                    self.browser.refresh()
                                        if self.browser.restart:
                                            quit()
                                        else:
                                            self.last_activity_time = datetimeutil.nowTimeStamp()
                                        time.sleep(8)
                                        self.browser.switchWindow(mainWindow)
                                        self.browser.drawCanvas(215, -120, 2)  # Click to Close button
                                        self.browser.drawCanvas(0, 50)  # Click to Claim button if 1 button
                                        self.browser.drawCanvas(-70,
                                                                60)  # Click to Claim button if 2 buttons, included Change Land button.
                                        time.sleep(10)
                                        if self.browser.windowsCount() > wc:
                                            isTransactionExpired = True
                                            countTransactionExpired += 1
                                            if countTransactionExpired >= 3:
                                                if configs.enableStakeWAX:
                                                    wax = self.browser.runJS_Return(
                                                        js.getStakedWAX % self.username).split(',')
                                                    try:
                                                        self.staked_wax = float(wax[0])
                                                    except:
                                                        self.staked_wax = 0
                                                    try:
                                                        self.available_wax = float(wax[1])
                                                    except:
                                                        self.available_wax = 0
                                                    if self.available_wax >= configs.amountStakeWAX and self.staked_wax < configs.maxAmountStakeWAX:
                                                        log.screen_n_file(self.index,
                                                                          '  [-] Transaction is expired in multi-time and/or out of resource. Try to stake more WAX.')
                                                        if self.StakeWAX():
                                                            log.screen_n_file(self.index,
                                                                              '  [+] Staked %f WAX successfully. Current staked WAX is %f.' % (
                                                                                  configs.amountStakeWAX,
                                                                                  self.staked_wax))
                                                            countTransactionExpired -= 1
                                                            isTransactionExpired = True
                                                            self.browser.switchWindow_Path(
                                                                configs.urlConfig['login'])
                                                        else:
                                                            log.screen_n_file(self.index,
                                                                              '  [-] Fail to stake WAX. Wait for %s then restart.' % (
                                                                                  datetimeutil.secondtoMinute(
                                                                                      configs.delayOutofCPU)))
                                                            SingleAccount.claiming -= 1
                                                            self.status = 12
                                                            for i in range(configs.delayOutofCPU):
                                                                self.browser.minimize()
                                                                self.last_activity_time = datetimeutil.nowTimeStamp()
                                                            self.status = 13
                                                            self.browser.restart = True
                                                            self.browser.restartReason = 'Transaction is expired in multi-time and/or out of resource. Restart thread now!'
                                                            self.browser.minimize()
                                                            time.sleep(10)
                                                    else:
                                                        log.screen_n_file(self.index,
                                                                          '  [-] Transaction is expired in multi-time and/or out of resource. Want to stake WAX but can not do now. Wait for %s then restart.' % (
                                                                              datetimeutil.secondtoMinute(
                                                                                  configs.delayOutofCPU)))
                                                        SingleAccount.claiming -= 1
                                                        self.status = 12
                                                        for i in range(configs.delayOutofCPU):
                                                            self.browser.minimize()
                                                            self.last_activity_time = datetimeutil.nowTimeStamp()
                                                        self.status = 13
                                                        self.browser.restart = True
                                                        self.browser.restartReason = 'Transaction is expired in multi-time and/or out of resource. Restart thread now!'
                                                        self.browser.minimize()
                                                        time.sleep(10)
                                                else:
                                                    log.screen_n_file(self.index,
                                                                      '  [-] Transaction is expired in multi-time and/or out of resource. Wait for %s then restart.' % (
                                                                          datetimeutil.secondtoMinute(
                                                                              configs.delayOutofCPU)))
                                                    SingleAccount.claiming -= 1
                                                    self.status = 12
                                                    for i in range(configs.delayOutofCPU):
                                                        self.browser.minimize()
                                                        self.last_activity_time = datetimeutil.nowTimeStamp()
                                                    self.status = 13
                                                    self.browser.restart = True
                                                    self.browser.restartReason = 'Transaction is expired in multi-time and/or out of resource. Restart thread now!'
                                                    self.browser.minimize()
                                                    time.sleep(10)
                                            else:
                                                isTransactionExpired = True
                                                self.browser.switchWindow_Path(configs.urlConfig['login'])
                                                log.screen_n_file(self.index,
                                                                  '  [-] Transaction is expired and/or Out of CPU.')
                                        break
                                    except:
                                        pass
                                if self.browser.restart:
                                    quit()
                                else:
                                    self.last_activity_time = datetimeutil.nowTimeStamp()
                            self.browser.switchWindow(mainWindow)
                            if isTransactionExpired and countTransactionExpired < 3:
                                continue
                            SingleAccount.claiming -= 1

                            # Completing
                            self.last_activity_time = datetimeutil.nowTimeStamp()
                            self.last_tlm = 0
                            self.delay_time = 0
                            while not self.browser.restart:
                                try:
                                    time.sleep(0.2)
                                    _logs = self.browser.log()
                                    if self.last_tlm == 0:
                                        for i in range(len(_logs)):
                                            _log = _logs[len(_logs) - i - 1]
                                            if 'Loaded Mining Bonus Scene - received ' in _log:
                                                try:
                                                    while True:
                                                        try:
                                                            t = \
                                                                re.findall(
                                                                    r'Loaded Mining Bonus Scene - received .* TLM',
                                                                    _log)[-1]
                                                        except:
                                                            break
                                                        _log = t.replace('Loaded Mining Bonus Scene - received ', '', 1)
                                                    self.last_tlm = float(input.santi(_log.replace(' TLM', '')))
                                                    break
                                                except:
                                                    pass
                                    if self.delay_time == 0:
                                        for i in range(len(_logs)):
                                            _log = _logs[len(_logs) - i - 1]
                                            if 'ms until next mine ' in _log:
                                                try:
                                                    self.time_to_delay_time = datetimeutil.nowTimeStamp()
                                                    self.delay_time = int(float(input.santi(
                                                        re.findall(r'ms until next mine .*', _log)[-1].replace(
                                                            'ms until next mine ', ''))) / 1000)
                                                    break
                                                except:
                                                    pass
                                    if self.last_tlm > 0 and self.delay_time > 0:
                                        break
                                except:
                                    pass
                            if self.browser.restart:
                                quit()
                            else:
                                self.last_activity_time = datetimeutil.nowTimeStamp()

                            self.browser.drawCanvas(-230, -225)  # Click to Home button.
                            self.browser.minimize()
                            self.mines += 1
                            self.delay_time -= datetimeutil.nowTimeStamp() - self.time_to_delay_time
                            log.screen_n_file(self.index, '  [+] Claimed %f TLM. Wait for %s.' % (
                                self.last_tlm, datetimeutil.secondtoMinute(self.delay_time)))
                            break
                        if self.browser.restart:
                            quit()
                        else:
                            self.last_activity_time = datetimeutil.nowTimeStamp()
                    else:
                        self.browser.minimize()
                        if self.cpu >= 100:
                            self.delay_time = configs.delayOutofCPU
                            log.screen_n_file(self.index,
                                              '  [-] Out of CPU (%d%%). Wait for %s.' % (
                                                  self.cpu, datetimeutil.secondtoMinute(self.delay_time)))
                            notification.notify(configs.app, 'Out of CPU (%d%%). Wait for %s.' % (
                                self.cpu, datetimeutil.secondtoMinute(self.delay_time)))
                        elif self.net >= 100:
                            self.delay_time = configs.delayOutofNET
                            log.screen_n_file(self.index, '  [-] Out of NET (%d%%). Wait for %s.' % (
                                self.net, datetimeutil.secondtoMinute(self.delay_time)))
                            notification.notify(configs.app, 'Out of NET (%d%%). Wait for %s.' % (
                                self.net, datetimeutil.secondtoMinute(self.delay_time)))
                        elif self.ram >= 100:
                            self.delay_time = configs.delayOutofRAM
                            log.screen_n_file(self.index, '  [-] Out of RAM (%d%%). Wait for %s.' % (
                                self.ram, datetimeutil.secondtoMinute(self.delay_time)))
                            notification.notify(configs.app, 'Out of RAM (%d%%). Wait for %s.' % (
                                self.ram, datetimeutil.secondtoMinute(self.delay_time)))

                    SingleAccount.current_hour = datetimeutil.nowHour()
                    if self.current_hour != SingleAccount.current_hour:
                        self.current_hour = SingleAccount.current_hour
                        if self.current_hour in configs.timeClaimNFTs:
                            log.screen_n_file(self.index, '[+] Now is time to claim NFTs.')
                            if self.ClaimNFTs():
                                log.screen_n_file(self.index, '  [+] Send claim NTFs request successfully.')
                            else:
                                log.screen_n_file(self.index, '  [-] Fail to send claim NFTs request.')

                    self.status = 12
                    if configs.enableCheckResource:
                        self.delay_time -= 5
                    if self.delay_time < 0:
                        self.delay_time = 0
                    for i in range(int(self.delay_time)):
                        self.browser.minimize()
                        self.last_activity_time = datetimeutil.nowTimeStamp()
                if self.browser.restart:
                    quit()
                else:
                    self.last_activity_time = datetimeutil.nowTimeStamp()
            else:
                try:
                    self.browser.quit()
                except:
                    pass
        except Exception as ex:
            log.screen_n_file(self.index, '[!] %s has exception: %s. Restart browser now!' % (configs.app, ex))
            notification.notify(configs.app, '%s has exception: %s. Restart browser now!' % (configs.app, ex))
            self.status = 13
            self.browser.restart = True
            self.browser.restartReason = 'Thread has exception. Restart thread now!'
            self.browser.minimize()
            time.sleep(10)
