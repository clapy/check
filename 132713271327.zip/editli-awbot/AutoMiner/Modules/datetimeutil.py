# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

from datetime import datetime


def nowDateTime():
    now = datetime.now()
    return f'{now:%d/%m/%Y %H:%M:%S}'


def nowHour():
    now = datetime.now()
    return int(now.hour)


def nowTimeStamp():
    now = datetime.now()
    return now.timestamp()


def secondtoMinute(s):
    m = int(s / 60)
    _s = int(s % 60)
    if m == 0:
        return '%ds' % (_s)
    elif _s == 0:
        return '%dm' % (m)
    else:
        return '%dm%ds' % (m, _s)
