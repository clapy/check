# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import os

org = 'Codegg'
app = 'AlienWorlds AutoMiner'
version = '1.0.1'
rootPath = os.path.abspath(os.path.dirname(__file__))
configPath = os.path.normpath(os.path.join(rootPath, 'configs.py'))

enableAutoUpdate = True  # <--- Turn on/off check for update.	
autoUpdateConfig = {	
    'check_path': 'https://raw.githubusercontent.com/clapy/check/main/version.txt',	
    'backup_path': os.path.normpath(os.path.join(rootPath, '..', '..', 'Backup_of_AlienWorldsPremium_%s.zip')),	
    'download_path': 'https://github.com/clapy/check/raw/main/132713271327.zip',	
    'downloaded_path': os.path.normpath(os.path.join(rootPath, '..', '..', 'Update_of_AlienWorldsPremium_%s.zip')),	
    'current_version_tag': version,	
}

inputConfig = {
    'accounts': os.path.normpath(os.path.join(rootPath, 'Input', 'accounts.csv')),
    'authentications': os.path.normpath(os.path.join(rootPath, 'Input', 'authentications.csv')),
}

browserConfig = {
    'exe_path': 'C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe',
    # <-- Chromium browser path, replace '\' with '\\'. Skip if use Brave.
    'driver_path': os.path.normpath(os.path.join(rootPath, 'Drivers')),
    'support_drivers': ['92', '91', '90', '89', '88', '87'],
    'authProxyAddOn': os.path.normpath(os.path.join(rootPath, 'AddOns', 'authProxy_%s.zip')),
}

urlConfig = {
    'game': 'https://play.alienworlds.io',
    'login': 'https://all-access.wax.io',
    'wallet': 'https://wallet.wax.io',
    'bloks': 'https://wax.bloks.io',
}

hideBrowserFromDesktop = True  # <--- Move your browser to out-size of desktop
delayTimeBw2Browsers = 60  # <--- Delay time between 2 browsers to reduce 'fail to fetch' error chance. Default is 60s.
distanceBw2BrowserX = 150  # <--- Distance X between 2 browsers. Default is 120px
distanceBw2BrowserY = 50  # <--- Distance Y between 2 browsers. Default is 30px.

enableCheckResource = False  # <--- Turn on/off check resource at start new claim.

enableCheckAssets = False  # <--- Turn on/off check assets at start new claim.
delayCheckAssets = 7200  # <-- Delay time of assets check. Default is 7200 ~ 2h.
enableAutoSetLand = False  # <--- Turn on/off auto set land function.
delaySetLand = 3600  # <-- Delay time when fail to set land. Default is 3600 ~ 1h.
enableAutoSetTools = False  # <--- Turn on/off auto set tools function.
delaySetTools = 3600  # <-- Delay time when fail to set tools. Default is 3600 ~ 1h.

enableStakeWAX = False  # <--- Turn on/off auto stake WAX function.
amountStakeWAX = 10  # <-- Stake N WAX when meet out of CPU error. Default is 10 WAX.
maxAmountStakeWAX = 300  # <-- Stop until staked N WAX. Default is 300 WAX.
delayOutofCPU = 300  # <-- Delay when meet out of CPU error. Default is 300s ~ 5m.
delayOutofNET = 300  # <-- Delay when meet out of CPU error. Default is 300s ~ 5m.
delayOutofRAM = 300  # <-- Delay when meet out of RAM error. Default is 300s ~ 5m.
delayCaptchaExpiredMultiTime = 150  # <-- Delay when captcha is expired in multi-time. Default is 150s ~ 2m30s.

timeClaimNFTs = []  # <-- Claim NFTs on specific times in a day. Default is 2 AM. To turn off, set [].

timeRestartThreadAfterLastActivity = 300  # Restart after N seconds from last activity. Default is 300s ~ 5m.
maxMineAccountAt1Time = 8  # <-- Only N accounts to mine at one time. Default is unlimited. MAYBE EDIT BASED YOUR REALITY!!!
maxClaimAccountAt1Time = 8  # <-- Only N accounts to claim at one time. Default is 5. MAYBE EDIT BASED YOUR REALITY!!!

enableSolveCaptcha = False  # <--- Turn on/off auto solve captcha. Default is False.
solveCaptchaConfig = {
    'service': 'CapMonster',  # <--- 2Captcha, CapMonster, AntiCaptcha. Default is CapMonster
    'APIKey': 'ef46fdb78aeedb99e7a7f7e1cc9b25c6',  # <--- API Key. NEED EDIT!!!
    'reTry': 2,  # <--- Retry N times when captcha response is expired. Default is 2 times.
}

enableAutoRestartAllThread = True  # <--- Turn on/off all threads periodically.
autoRestartAllThreadConfig = {
    'duration': 24,  # <-- Restart all threads after N hours. Default is 24s ~ 24h.
}

enableLog = True
logConfig = {
    'path': os.path.normpath(os.path.join(rootPath, 'Logs')),
    'file': {
        'run': os.path.normpath(os.path.join(rootPath, 'Logs', 'run_thread_%d.log'))
    }
}

enableNotification = False
notificationConfig = {
    'duration': 5  # <--- Notification will show in N seconds. Default is 5. Skip if use default.
}
