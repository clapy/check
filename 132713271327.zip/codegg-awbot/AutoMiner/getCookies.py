# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import time
import urllib.parse as urlparse

import configs
from Modules import input, browser, captcha, js, log

authentications = input.readAuthentications()
accounts = [
    ['Token ID', 'Session Token', 'Proxy', 'Land', 'Tools', 'Username'],
]

br = browser.Browser()
br.init()
px = 0
if configs.hideBrowserFromDesktop:
    py = 3600
else:
    py = 0
br.start(px, py)

log.screen_n_file(0, '[*] Auto solve captcha')
log.screen_n_file(0, '[*] Real-time update to account.csv')
for authentication in authentications:
    try:
        br.get(configs.urlConfig['login'])
        br.browser.find_element_by_xpath("//input[contains(@name, 'userName')]").send_keys(authentication[0])
        br.browser.find_element_by_xpath("//input[contains(@name, 'password')]").send_keys(authentication[1])

        if len(br.browser.find_elements_by_xpath("//iframe[contains(@title, 'reCAPTCHA')]")) > 0:
            rc = captcha.Captcha()
            while True:
                recaptcha = br.browser.find_element_by_xpath(
                    "//iframe[contains(@title, 'reCAPTCHA')]")
                sitekey = ''
                for query in urlparse.urlparse(recaptcha.get_attribute('src')).query.split('&'):
                    if 'k=' in str(query):
                        sitekey = str(query).split('=')[1]
                token = rc.reCaptcha(sitekey, br.url())
                if token != 'Expired':
                    log.screen_n_file(0, '    [+] Captcha response is %s.' % (token[:7] + '...' + token[-7:]))
                    br.runJS(js.reCaptchaCallbackFunction % token)
                    break
                else:
                    br.runJS(js.reCaptchaReset)
        br.browser.find_element_by_xpath("//button[contains(text(), 'Login')]").click()
        time.sleep(2)
        while True:
            try:
                token_id = ''
                session_token = ''
                _ckes = br.cookies()
                for _ck in _ckes:
                    if _ck['name'] == 'token_id':
                        token_id = _ck['value']
                    elif _ck['name'] == 'session_token':
                        session_token = _ck['value']
                if token_id != '' and session_token != '':
                    accounts.append([token_id, session_token, '', '', '', ''])
                    input.writeInput(accounts, 'accounts')
                    log.screen_n_file(0, '[+] Added new row to accounts.csv.')
                    break
                time.sleep(0.2)
            except:
                pass
        br.clearCookies()
    except:
        pass

br.quit()
