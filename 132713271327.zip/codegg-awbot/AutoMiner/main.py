# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use
# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import threading, time

import configs
from Modules import single_account, input, datetimeutil, notification, log, update

accounts = input.readAccounts()
ma = []
for i in range(len(accounts)):
    sa = single_account.SingleAccount(accounts[i], i)
    ma.append(sa)
threads = []


def restartChecker():
    global ma
    global threads

    while True:
        startAllThread = datetimeutil.nowTimeStamp()
        time.sleep(1)
        try:
            if configs.enableAutoRestartAllThread and datetimeutil.nowTimeStamp() > startAllThread + \
                    configs.autoRestartAllThreadConfig['duration']:
                for i in range(len(ma)):
                    ma[i].browser.restart = True
                    try:
                        ma[i].restart()
                    except:
                        pass
                    try:
                        ma[i].browser.restarting = True
                    except:
                        pass
                    ma[i] = single_account.SingleAccount(accounts[i], i)
                    threads[i] = threading.Thread(target=handler, args=(i,))
                single_account.SingleAccount.mining = 0
                single_account.SingleAccount.claiming = 0
                for i in range(len(ma)):
                    threads[i].start()
                    time.sleep(configs.delayTimeBw2Browsers)
            else:
                for i in range(len(ma)):
                    if ma[i].browser is not None:
                        if ma[i].browser.restart == True:
                            if not ma[i].browser.restarting:
                                try:
                                    ma[i].restart()
                                except:
                                    pass
                                try:
                                    ma[i].browser.restarting = True
                                except:
                                    pass
                                ma[i] = single_account.SingleAccount(accounts[i], i)
                                threads[i] = threading.Thread(target=handler, args=(i,))
                                threads[i].start()
                        elif ma[i].last_activity_time > 0 and datetimeutil.nowTimeStamp() > ma[
                            i].last_activity_time + configs.timeRestartThreadAfterLastActivity:
                            if not ma[i].browser.restarting:
                                ma[
                                    i].browser.restartReason = 'Thread is paused for long time (%s). Restart thread now!' % datetimeutil.secondtoMinute(
                                    configs.timeRestartThreadAfterLastActivity)
                                try:
                                    ma[i].restart()
                                except:
                                    pass
                                try:
                                    ma[i].browser.restarting = True
                                except:
                                    pass
                                ma[i] = single_account.SingleAccount(accounts[i], i)
                                threads[i] = threading.Thread(target=handler, args=(i,))
                                threads[i].start()
        except:
            pass


def corrector():
    global ma

    while True:
        try:
            time.sleep(600)
            data = [
                ['Token ID', 'Session Token', 'Proxy', 'Land', 'Tools', 'Username']
            ]
            for i in range(len(ma)):
                if ma[i] is not None:
                    accounts[i][3] = ma[i].land
                    tools = []
                    for tool in ma[i].tools:
                        tools.append('"' + tool + '"')
                    accounts[i][4] = ma[i].tools
                    accounts[i][5] = ma[i].username
                data.append(
                    [accounts[i]['cookies'][0]['value'], accounts[i]['cookies'][1]['value'], accounts[i]['proxy'],
                     '"' + accounts[i]['land'] + '"', '[' + '.'.join(accounts[i]['tools']) + ']',
                     accounts[i]['username']])
                input.writeInput(data, 'accounts')
        except:
            pass


# def statusConverter(status):
#     if status == 0:
#         return 'New'
#     elif status == 1:
#         return 'Initial'
#     elif status == 2:
#         return 'Logging-in to WAX'
#     elif status == 3:
#         return 'Logging-in to AlieWorlds'
#     elif status == 4:
#         return 'Getting resources'
#     elif status == 5:
#         return 'Getting assets'
#     elif status == 6:
#         return 'Setting land'
#     elif status == 7:
#         return 'Setting tools'
#     elif status == 8:
#         return 'Waiting at home screen'
#     elif status == 9:
#         return 'Mining'
#     elif status == 10:
#         return 'Claiming'
#     elif status == 11:
#         return 'Signing'
#     elif status == 12:
#         return 'Sleeping'
#     elif status == 13:
#         return 'Restarting'
#     elif status == 14:
#         return 'Staking WAX'
#     elif status == 15:
#         return 'Claiming NFTs'

def handler(i):
    global ma

    try:
        ma[i].AutoMiner()
    except:
        pass


def MultiAccount():
    global ma
    global threads

    log.clear()
    try:
        restartChecker_thread = threading.Thread(target=restartChecker, args=())
        corrector_thread = threading.Thread(target=corrector, args=())
        for i in range(len(ma)):
            threads.append(threading.Thread(target=handler, args=(i,)))
        if len(threads) == 0:
            raise Exception('No account to run')
        restartChecker_thread.start()
        corrector_thread.start()
        for i in range(len(threads)):
            threads[i].start()
            if i < len(threads) - 1:
                log.screen_n_file(9999, '[*] To prevent ban from Wax, the next thread will start after %s!' % (
                    datetimeutil.secondtoMinute(configs.delayTimeBw2Browsers)))
            time.sleep(configs.delayTimeBw2Browsers)
    except Exception as ex:
        log.screen_n_file(9999, '[!] %s has exception: %s!' % (configs.app, ex))
        notification.notify(configs.app, '%s has exception: %s!' % (configs.app, ex))
        
if update.check():	
    MultiAccount()	
