# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import configs
from Modules import datetimeutil, log

import time, zipfile
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver import Proxy
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


class Browser:
    default_web_driver_version = ''

    def __init__(self, index=0):
        self.index = index
        self.driver_index = 0
        self.driver = ''
        self.path = configs.browserConfig['exe_path']
        self.opts = None
        self.cap = None
        self.browser = None
        self.px = 0
        self.py = 0
        self.sx = 0
        self.sy = 0
        self.last_log_time_stamp = 0
        self.restart = False
        self.restartReason = None
        self.restarting = False

    def getBrowserName(self):
        exeFileName = self.path.split('\\')[-1].split('.')[0].lower()
        if exeFileName == 'brave':
            return 'Brave'
        elif exeFileName == 'chrome':
            return 'Chrome'
        elif exeFileName == 'netboxbrowser':
            return 'NetBox'
        else:
            return 'Other'

    def authProxy(self, proxy):
        t = proxy.split(':')
        proxy_host = t[0]
        proxy_port = t[1]
        proxy_user = t[2]
        proxy_pass = t[3]
        manifest_json = '''
            {
                "version": "1.0.0",
                "manifest_version": 2,
                "name": "Chrome Proxy",
                "permissions": [
                    "proxy",
                    "tabs",
                    "unlimitedStorage",
                    "storage",
                    "<all_urls>",
                    "webRequest",
                    "webRequestBlocking"
                ],
                "background": {
                    "scripts": ["background.js"]
                },
                "minimum_chrome_version":"22.0.0"
            }
        '''
        background_js = '''
            var config = {
                    mode: "fixed_servers",
                    rules: {
                    singleProxy: {
                        scheme: "http",
                        host: "%s",
                        port: parseInt(%s)
                    },
                    bypassList: ["localhost"]
                    }
                };

            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "%s",
                        password: "%s"
                    }
                };
            }

            chrome.webRequest.onAuthRequired.addListener(
                        callbackFn,
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            ''' % (proxy_host, proxy_port, proxy_user, proxy_pass)
        plugin_file = configs.browserConfig['authProxyAddOn'] % self.index
        with zipfile.ZipFile(plugin_file, 'w') as zf:
            zf.writestr("manifest.json", manifest_json)
            zf.writestr("background.js", background_js)

        return plugin_file

    def init(self, proxy='YourProxy'):
        self.opts = Options()
        self.opts.binary_location = self.path
        self.opts.add_experimental_option('useAutomationExtension', False)
        self.opts.add_experimental_option('excludeSwitches', ['enable-automation'])
        self.opts.add_argument('--log-level=3')
        self.opts.add_argument('--mute-audio')
        self.cap = DesiredCapabilities.CHROME.copy()
        self.cap['platform'] = 'WINDOWS'
        self.cap['version'] = '10'
        self.cap['goog:loggingPrefs'] = {'browser': 'ALL'}
        if proxy != '' and proxy != 'YourProxy':
            if len(proxy.split(':')) == 2:
                proxies = Proxy({
                    'httpProxy': proxy,
                    'ftpProxy': proxy,
                    'sslProxy': proxy,
                    'proxyType': 'MANUAL',
                })
                proxies.add_to_capabilities(self.cap)
            elif len(proxy.split(':')) == 4:
                self.opts.add_extension(self.authProxy(proxy))
        if Browser.default_web_driver_version == '':
            self.driver = configs.browserConfig['driver_path'] + '\\' + configs.browserConfig['support_drivers'][
                self.driver_index] + '.exe'
        else:
            self.driver = configs.browserConfig['driver_path'] + '\\' + Browser.default_web_driver_version + '.exe'

    def changeDriver(self):
        if self.driver_index + 1 <= len(configs.browserConfig['support_drivers']) - 1:
            self.driver_index += 1
            self.driver = configs.browserConfig['driver_path'] + '\\' + configs.browserConfig['support_drivers'][
                self.driver_index] + '.exe'
            return True
        return False

    def start(self, px=0, py=0):
        while True:
            try:
                self.browser = webdriver.Chrome(desired_capabilities=self.cap, options=self.opts,
                                                executable_path=self.driver)
                Browser.default_web_driver_version = configs.browserConfig['support_drivers'][self.driver_index]
                log.screen_n_file(self.index,
                                  '[*] Decide to choose web driver version %s to run.' % Browser.default_web_driver_version)
                break
            except Exception as ex:
                if 'This version of ChromeDriver only supports' in str(ex):
                    log.screen_n_file(self.index,
                                      '[*] Web driver version %s is not supported your browser. Switching to other web driver...' %
                                      configs.browserConfig['support_drivers'][self.driver_index])
                    if not self.changeDriver():
                        log.screen_n_file(self.index,
                                          '[!] All of web drivers are not supported your browser. Please update browser or download web driver.')
                        time.sleep(999999)

        self.px = px
        if configs.hideBrowserFromDesktop:
            self.py = py - 3600
        else:
            self.py = py
        self.browser.set_window_position(self.px, self.py)
        self.sx = 854
        if self.getBrowserName() == 'Brave':
            self.sy = 720
        else:
            self.sy = 676
        self.browser.set_window_size(self.sx, self.sy)

    def cookies(self):
        try:
            return self.browser.get_cookies()
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def setCookies(self, cookies):
        try:
            for cookie in cookies:
                self.browser.delete_cookie(cookie['name'])
                self.browser.add_cookie(cookie)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def clearCookies(self):
        try:
            cookies = self.browser.get_cookies()
            for cookie in cookies:
                self.browser.delete_cookie(cookie['name'])
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def get(self, path):
        try:
            self.browser.get(path)
            time.sleep(2)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def setTitle(self, title=''):
        try:
            self.browser.execute_script('''
                    document.title = '%s';
                ''' % title)
            time.sleep(1)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def refresh(self):
        try:
            self.browser.get(self.browser.current_url)
            time.sleep(2)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def window(self):
        try:
            return self.browser.current_window_handle
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
        return ''

    def windowsCount(self):
        try:
            return len(self.browser.window_handles)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
        return 0

    def windows(self):
        try:
            return self.browser.window_handles
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
        return []

    def url(self):
        try:
            return self.browser.current_url
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
        return ''

    def source(self):
        try:
            return self.browser.page_source
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
        return ''

    def newWindow(self, path):
        try:
            self.browser.execute_script('''
                window.open(arguments[0], '_blank');
            ''', path)
            time.sleep(2)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def switchWindow(self, window):
        try:
            self.browser.switch_to.window(window)
            time.sleep(0.2)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def switchWindow_Path(self, path):
        try:
            current_window = self.browser.current_window_handle
            if path not in self.browser.current_url:
                for handle in self.browser.window_handles:
                    if handle != current_window:
                        self.browser.switch_to.window(handle)
                        time.sleep(0.2)
                        if path in self.browser.current_url:
                            break
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def runJS(self, jsCode=''):
        try:
            self.browser.execute_script(jsCode)
            time.sleep(2)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def runJS_Return(self, jsCode='', keyWord='RunJS'):
        startRunJS = datetimeutil.nowTimeStamp()
        while True:
            try:
                time.sleep(0.2)
                self.browser.execute_script(jsCode)
                time.sleep(5)
                for i in range(15):
                    time.sleep(1)
                    if keyWord in self.browser.title:
                        result = str(self.browser.title).replace(keyWord, '')
                        self.setTitle()
                        return result
                if datetimeutil.nowTimeStamp() > startRunJS + 60:
                    return ''
            except Exception as ex:
                if 'not reachable' in str(ex):
                    self.restart = True
                    self.restartReason = 'User turn off browser. Restart thread now!'
                break

    def drawCanvas(self, xoffset, yoffset, delay=1, prinfOffset=False):
        try:
            if prinfOffset:
                print(xoffset, yoffset)
            canvas = self.browser.find_element_by_xpath("//canvas[contains(@id, '#canvas')]")
            action = ActionChains(self.browser)
            action.move_to_element(canvas)
            action.move_by_offset(xoffset=xoffset, yoffset=yoffset)
            action.click()
            action.perform()
            time.sleep(delay)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def log(self):
        try:
            last_log_time_stamp = self.last_log_time_stamp
            logs = []
            entries = self.browser.get_log('browser')
            for entry in entries:
                if entry["timestamp"] >= last_log_time_stamp:
                    if entry["timestamp"] > self.last_log_time_stamp:
                        self.last_log_time_stamp = entry["timestamp"]
                    logs.append(entry["message"])
            return logs
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
        return []

    def minimize(self):
        try:
            self.browser.minimize_window()
            time.sleep(1)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def restore(self):
        try:
            self.browser.set_window_position(self.px, self.py)
            self.browser.set_window_size(self.sx, self.sy)
            time.sleep(1)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def close(self):
        try:
            self.browser.close()
            time.sleep(1)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def closeOthers(self, window):
        try:
            for handle in self.browser.window_handles:
                if handle != window:
                    self.browser.switch_to.window(handle)
                    self.browser.close()
                    time.sleep(1)
            self.browser.switch_to.window(window)
            time.sleep(0.2)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'

    def quit(self):
        try:
            self.browser.quit()
            time.sleep(1)
        except Exception as ex:
            if 'not reachable' in str(ex):
                self.restart = True
                self.restartReason = 'User turn off browser. Restart thread now!'
