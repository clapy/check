# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import configs

try:
    import winsound
    from win10toast import ToastNotifier
except:
    pass


def notify(app, content):
    try:
        if configs.enableNotification:
            toast = ToastNotifier()
            toast.show_toast(app, content, duration=configs.notificationConfig['duration'])
    except:
        pass


def sound():
    try:
        if configs.enableNotification:
            winsound.Beep(999, 500)
    except:
        pass
