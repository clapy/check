# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import os
from datetime import datetime

import configs
from Modules import datetimeutil



def clear():
    try:
        for fn in os.listdir(configs.logConfig['path']):
            fp = os.path.join(configs.logConfig['path'], fn)
            if os.path.isfile(fp) or os.path.islink(fp):
                os.unlink(fp)
    except:
        pass


def screen(thread, log, haveDateTime=False):
    try:
        if configs.enableLog:
            if haveDateTime:
                now = datetime.now()
                log = ' [Thread %d] [At %s] %s ' % (thread, f'{now:%d/%m/%Y %H:%M:%S}', log)
            else:
                log = ' [Thread %d] %s ' % (thread, log)
            print(log)
    except:
        pass


def file(thread, log, haveDateTime=True):
    try:
        if configs.enableLog:
            fn = configs.logConfig['file']['run'] % thread
            f = open(fn, 'a')
            if haveDateTime:
                now = datetime.now()
                log = ' [At %s] %s ' % (f'{now:%d/%m/%Y %H:%M:%S}', log)
            else:
                log = ' %s ' % (log)
            f.write(log + '\n')
            f.close()
            return True
    except:
        pass
    return False


def screen_n_file(thread, log, haveDateTime=True):
    try:
        if configs.enableLog:
            screen(thread, log, haveDateTime)
            file(thread, log, haveDateTime)
    except:
        pass
