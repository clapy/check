# AlienWorlds Auto Claim TLM - Premium version

The free version (v1.4) has stopped developing new features, but still maintains the patch.

The premium version (v1.5g) is developing. It's more stable, more accurate, faster, lighter for multiple accounts. The auto
script will be located **in this [private repository](https://github.com/autoalmosteverything/AlienWorldsPremium) only
available to those who have received my invitation (from now, I will call "Right of Access", RoA).** When buying RoA,
you can access, download it anytime, use it for **any account on any computer**, without limitation (except sharing). I
will support the first-time setup and continue update new features in the future.

**For those of you who have donated money, WAXP, BTC** when I develop the community version, **I will give free RoA**.
This is a recognition of your support. Thank you!

**For those who want to use the premium version**, I will announce the price for each milestone of development. Expected
from **$ 20 for the early versions, later the price will increase**. Please note that **you purchased RoA, not a
license**, so, it's cheaper. And no more fees in the future.

| Version  | Price | Access |
| --- | --- | --- |
| ~~v1.4~~  | ~~20$ (7 clients purchased)~~  | ~~from v1.4~~ |
| **v1.5**  | **70$** | **from v1.5**  |
| v1.6 (Release soon)  | 100$ | from v1.6  |

**<img src="https://www.svgrepo.com/show/10101/star.svg" width="12" height="12"> Current version is v1.5g. Price from
v1.5 is 70$**. Price will be increased to 100$ for v1.6.

**<img src="https://www.svgrepo.com/show/210826/sale.svg" width="12" height="12"> Sale off**: ~~First **10** peoples who
purchase from now, price is only **50$**.~~ Please wait for the next Sale-off!

**<img src="https://www.svgrepo.com/show/77415/youtube.svg" width="12" height="12">
Demo:** [View on Youtube](https://www.youtube.com/watch?v=iCNKzIGHL2c).

**<img src="https://www.svgrepo.com/show/29779/wallet.svg" width="12" height="12"> Accept:** PayPal, Payeer, WAXP, TLM,
Bank.

**<img src="https://www.svgrepo.com/show/103017/letter.svg" width="12" height="12"> AAE Premium Contact
Point:** [Google Form](https://docs.google.com/forms/d/e/1FAIpQLSdWPn6ZqbKJiQf9EKzt2exOTirjdR_7WY-dnjU_h9wDyzZu7Q/viewform)
| [Email](mailto:autoalmosteverything.2021@gmail.com)

**<img src="https://www.svgrepo.com/show/206432/alert.svg" width="12" height="12"> Note:** We do not allow the user to share our Premium product. If we detect who uses the unauthorized Premium product from us, we will send an alert email with a time to verify. When the period ends, **we are not responsible for any of your issues and will not consider any complaint in the future**. There is no exception, so take care! 

### [English - Tiếng Việt bên dưới]

TLM is listed on Binance. read more on [CoinMarketCap](https://coinmarketcap.com/vi/currencies/alien-worlds/).

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Functions:

1. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Auto get cookies from username,
   password.**
2. Claim TLM, **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> NFTs**.
3. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
   Multi-account**.
    - **Centralized config.**
    - **Import accounts from Excel file: cookies, proxy, land, tools.**
    - **Concurrency mechanism.**
    - **Allow unlimited account amount.**
4. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> ALLOW
   USE WITHOUT CAPTCHA, BASED NEW UPDATE OF WAX ON 28/05/2021**
5. Automatically solve captcha by using:

   5.1. 2Captcha, [Register here](https://2captcha.com?from=11528745).

   5.2. CapMonster, [Register here](https://capmonster.cloud/).

   5.3. Anti-Captcha, [Register here](https://anti-captcha.com/).

6. Handle the expired captcha to try again.
7. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Get username, balance, resource information (from WAX), and delay time (based current land, tools or latest transaction)**.
8. Handle `out of CPU, NET and RAM` error.
    - Always check before mine.
    - Wait until the used amount returns under 100%.
    - **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Or stake small amount to reset CPU.**
9. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
   Handle problem `change land` and `drop tools`.**
    - **Always check before mine.**
    - **Auto `set land` and `set bag`.**
10. Handle `fail to fetch` error: try to login again.
11. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
    Prevent falling into an endless loop when mining.**
12. Handle `transaction is expired` error: try to claim again.
13. Smoothly run by auto ignoring other errors.
14. Support proxy (include authentication proxy).
15. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
    Allow restart a thread of multi threads at any time.**
16. Logging:
    - Screen.
    - File.
17. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Auto
    update.**

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> History:

**v1.0 Community** [View on Youtube](https://www.youtube.com/watch?v=NWUMdimjPPE)

- Claim TLM.

**v1.1 Community** [View on Youtube](https://www.youtube.com/watch?v=qvD0Kp5Sp30)

- Automatically solve captcha by using 2Captcha.
- Handle the expired captcha to try again.
- Smoothly run by auto ignoring other errors.

**v1.2 Community** [View on Youtube](https://youtu.be/6XfwxT-w4_I)

- Get username, balance, resource information (from WAX).
- Handle `out of CPU, NET and RAM` error:
    - Always check resource before mine.
    - Wait until the used resource amount returns under 100%.

**v1.3 Community** [View on Youtube](https://www.youtube.com/watch?v=kiVkAjCedSU)

- Handle `transaction is expired` error: try to claim again.

**v1.4 Community & Premium** [View on Youtube](https://www.youtube.com/watch?v=nFb3mL9LP9Q)

- Switch to one time login instead of the loop of turn off/turn on browser.
- Add CapMonster as 2nd anti-captcha service.
- Handle `fail to fetch` error: try to login again.
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Get
  delay time (based current land, tools or latest transaction).**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
  Prevent falling into an endless loop when mining.**
- Support proxy.
- Add logging function.

**v1.5 Premium** [View on Youtube](https://www.youtube.com/watch?v=iCNKzIGHL2c)

- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
  Multi-account**.
    - **Centralized config.**
    - **Import from Excel file: cookies, proxy, land, tools.**
    - **Concurrency mechanism.**
    - **Allow unlimited account amount.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Add
  Anti-Captcha as 3rd anti-captcha service.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Handle
  problem `change land` and `drop tools`.**
    - **Always check before mine.**
    - **Auto set land and set bag.**

**v1.6 Premium** Release soon. Price will increase to **100$**.

- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> ALLOW
  USE WITHOUT CAPTCHA, BASED NEW UPDATE OF WAX ON 28/05/2021**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
  Support authentication proxy.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Auto
  get cookies from username, password.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Stake
  small amount to reset CPU.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Auto
  claim NFTs.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Allow
  restart a thread of multi threads at any time.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Auto
  update.**

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Config and run:

1. Click `1. CLICK_HERE_to_setup.bat` to setup Python, Brave.
2. Click `2. CLICK_HERE_to_install_modules.bat` to install modules.
3. Configure in `configs.py`.
4. (_Optional_) If use auto get cookies function, please input username and password to `authentication.csv`.
5. Click `3. CLICK_HERE_to_get_cookies.bat` to get cookies, export to `accounts.csv`.
6. Review account list in `accounts.csv`. Add _proxy_, _land_, _tools_ if needed.
7. Click `4. CLICK_HERE_to_run.bat` to start the game!

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Note:

- **Do not resize** the browser's window.
- **Free of mouse**.

### [Tiếng Việt - English above]

TLM đã lên sàn Binance. Xem thêm trên [CoinMarketCap](https://coinmarketcap.com/vi/currencies/alien-worlds/).

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Tính năng:

1. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Tự động lấy cookies từ tài
   khoản, mật khảu.**
2. Nhận TLM, NFTs.
3. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
   Chạy nhiều tài khoản.**
    - **Cấu hình tập trung.**
    - **Nhập nhiều tài khoản từ file Excel: cookies, proxy, land, tools.**
    - **Cơ chế xử lý đồng thời.**
    - **Cho phép không giới hạn tài khoản.**
4. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> CHO
   PHÉP CHẠY KHÔNG CẦN CAPTCHA, THEO CẬP NHẬT MỚI NHẤT NGÀY 28/05/2021.**
5. Tự động giải captcha bằng:

   5.1. 2Captcha, [Đăng ký tại đây](https://2captcha.com?from=11528745).

   5.2. CapMonster, [Đăng ký tại đây](https://capmonster.cloud/).

   5.3. Anti-Captcha, [Đăng ký tại đây](https://anti-captcha.com/).

6. Xử lý captcha quá hạn để thử lại.
7. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Lấy thông tin người chơi, số dư, tài nguyên (từ WAX), và thời gian đợi (dựa trên đất, công cụ hiện tại hoặc giao dịch mới nhất)**.
8. Xử lý lỗi `out of CPU, NET and RAM`.
    - Luôn kiểm tra trước khi khai thác.
    - Đợi đến khi lượng tài nguyên đã sử dụng trở về dưới 100%.
    - **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
      Hoặc stake một lượng nhỏ để reset CPU.**
9. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
   Xử lý vấn đề `change land` và `drop tools`.**
    - **Luôn kiểm tra trước khi khai thác.**
    - **Tự động `set land` và `set bag`.**
10. Xử lỹ lỗi `fail to fetch`: Cố gắng đăng nhập lại.
11. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
    Chống treo khi khai thác.**
12. Xử lý lỗi `transaction is expired`: Cố gắng nhận lại.
13. Chạy mượt bằng cách tự bỏ qua các lỗi khác.
14. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Cho
    phép khởi động lại một thread bất kỳ lúc nào.**
14. Hỗ trợ proxy (bao gồm proxy có username, password).
15. Ghi log:
    - Màn hình.
    - Tập tin.
16. **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Tự
    động cập nhật**

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Lịch sử:

**v1.0 Community** [Xem trên Youtube](https://www.youtube.com/watch?v=NWUMdimjPPE)

- Nhận TLM.

**v1.1 Community** [Xem trên Youtube](https://www.youtube.com/watch?v=qvD0Kp5Sp30)

- Tự động giải captcha bằng 2Captcha.
- Xử lý captcha quá hạn để thử lại.
- Chạy mượt bằng cách tự bỏ qua các lỗi khác.

**v1.2 Community** [Xem trên Youtube](https://youtu.be/6XfwxT-w4_I)

- Lấy thông tin người chơi, tài nguyên (từ WAX).
- Xử lý lỗi `out of CPU, NET, and RAM`:
    - Kiểm tra tài nguyên trước khi khai thác.
    - Đợi cho đến khi lượng tài nguyên đã sử dụng trở về dưới 100%.

**v1.3 Community** [Xem trên Youtube](https://www.youtube.com/watch?v=kiVkAjCedSU)

- Xử lý lỗi `transaction is expired`: cố gắng nhận lại.

**v1.4 Community & Premium** [View on Youtube](https://www.youtube.com/watch?v=nFb3mL9LP9Q)

- Chuyển sang đăng nhập 1 lần thay vì vòng lặp mở/tắt trình duyệt.
- Thêm dịch vụ giải captcha thứ hai CapMonster.
- Xử lý lỗi `fail to fetch` error: Cố gắng đăng nhập lại.
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Lấy
  thời gian đợi (dựa trên đất, công cụ hiện tại hoặc giao dịch mới nhất).**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Chống
  treo khi khai thác.**
- Hỗ trợ proxy.
- Thêm tính năng ghi log.

**v1.5 Premium** [Xem trên Youtube](https://www.youtube.com/watch?v=iCNKzIGHL2c)

- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
  Chạy nhiều tài khoản.**
    - **Cấu hình tập trung.**
    - **Nhập nhiều tài khoản từ file Excel: cookies, proxy, land, tools.**
    - **Cơ chế xử lý đồng thời.**
    - **Cho phép không giới hạn tài khoản.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Thêm
  dịch vụ giải captcha thứ ba Anti-Captcha.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version">
  Xử lý vấn đề `change land` và `drop tools`.**
    - **Luôn kiểm tra trước khi khai thác.**
    - **Tự động `set land` và `set bag`.**

**v1.6 Premium** Sẽ phát hành sớm. Giá sẽ tăng lên **100$**.

- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> CHO
  PHÉP CHẠY KHÔNG CẦN CAPTCHA, THEO CẬP NHẬT MỚI NHẤT CỦA WAX NGÀY 28/05/2021.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Hỗ trợ
  proxy có username và password.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Tự
  động lấy cookies từ tài khoản, mật khảu.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Stake
  một lượng nhỏ để reset CPU.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Tự
  nhận NFTs.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Cho
  phép khởi động lại một thread bất kỳ lúc nào.**
- **<img src="https://www.svgrepo.com/show/196054/premium.svg" width="20" height="20" title="In premium version"> Tự
  động cập nhật.**
  
##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Cài đặt:

1. Click `1. CLICK_HERE_to_setup.bat` để cài đặt Python, Brave.
2. Click `2. CLICK_HERE_to_install_modules.bat` để cài đặt modules.
3. Tùy chỉnh cấu hình trong tập tin `configs.py`.
4. (_Tự chọn_) Nếu sử dụng tính năng lấy nhanh cookies, vui lòng nhập tài khoản và mật khẩu vào tập tin `authentication.csv`.
5. Click `3. CLICK_HERE_to_get_cookies.bat` để lấy nhanh cookies, xuất ra tập tin `accounts.csv`.
6. Kiểm tra danh sách tài khoản trong `accounts.csv`. Thêm _proxy_, _land_, _tools_ nếu có nhu cầu.
7. Click `4. CLICK_HERE_to_run.bat` để bắt đầu trò chơi!

##### <img src="https://www.svgrepo.com/show/226569/rec-dot.svg" width="12" height="12"> Chú ý:

- **Không thay đổi** kích thước của sổ trình duyệt.
- Auto **không chiếm chuột**.

# Auto Almost Everything

- Email: autoalmosteverything.2021@gmail.com
- Youtube: https://www.youtube.com/c/AutoAlmostEverything
- Github: https://github.com/autoalmosteverything
- Facebook: https://www.facebook.com/autoalmosteverything
