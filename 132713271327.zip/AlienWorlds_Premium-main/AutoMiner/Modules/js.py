# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

getResInfo = '''
    async function get_res() {
        const username = '%s'
        const response = await fetch('https://api.waxsweden.org/v1/chain/get_account', {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json'
            },
            redirect: 'follow',
            referrerPolicy: 'no-referrer',
              body: JSON.stringify({ account_name: username }),
        })
        const json = await response.json();
        const cpu = await ((json['cpu_limit']['used'] / json['cpu_limit']['max']) * 100).toFixed(0)
        const net = await ((json['net_limit']['used'] / json['net_limit']['max']) * 100).toFixed(0)
        document.title = 'RunJS' + cpu + ',' + net;
    }
    
    get_res();
'''

getStakedWAX = '''
    async function get_res() {
        const username = '%s'
        const response = await fetch('https://api.waxsweden.org/v1/chain/get_account', {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json'
            },
            redirect: 'follow',
            referrerPolicy: 'no-referrer',
              body: JSON.stringify({ account_name: username }),
        })
        const json = await response.json();
        const staked = await json['total_resources']['cpu_weight'].replace(' WAX', '');
        const available = await json['core_liquid_balance'].replace(' WAX', '');
        document.title = 'RunJS' + staked + ',' + available;
    }

    get_res();
'''

getAssetsInfo = '''
    async function get_items(username) {
        const response = await fetch('https://wax.greymass.com/v1/chain/get_table_rows', {
            method: 'POST',
            body: JSON.stringify({
                code: "m.federation",
                index_position: 1,
                json: true,
                key_type: "",
                limit: 10,
                lower_bound: username,
                reverse: false,
                scope: "m.federation",
                show_payer: false,
                table: "bags",
                table_key: "",
                upper_bound: username,
            }),
        })
        const json = await response.json();
        const items = await json['rows'][0]['items'];
        return items;
    }
    
    async function get_land(username) {
        const response = await fetch('https://wax.greymass.com/v1/chain/get_table_rows', {
            method: 'POST',
            body: JSON.stringify({
                code: "m.federation",
                index_position: 1,
                json: true,
                key_type: "",
                limit: 10,
                lower_bound: username,
                reverse: false,
                scope: "m.federation",
                show_payer: false,
                table: "miners",
                table_key: "",
                upper_bound: username,
            }),
        })
        const json = await response.json();
        const land = await json['rows'][0]['current_land'];
        return land;
    }
    
    async function get_assets_info() {
        const username = "%s";
        const items =	await get_items(username);
        let str_items = '';
        for (let i in items) {
            str_items += items[i] + '.'
        }
        const land = await get_land(username);
        document.title = 'RunJS' + land + ',[' + str_items + '],';
    }
    
    get_assets_info();
'''

reCaptchaReset = '''
    window.grecaptcha.reset();
'''

reCaptchaCallbackFunction = '''
    function call_cbf(token) {
        let widgetId = 0;
        let widget = ___grecaptcha_cfg.clients[widgetId];
        let callback = undefined;
        for (let k1 in widget) {
            let obj = widget[k1];
            if (typeof obj !== "object") continue;
            for (let k2 in obj) {
                if (obj[k2] === null) continue;
                if (typeof obj[k2] !== "object") continue;
                if (obj[k2].callback === undefined) continue;
                callback = obj[k2].callback;
                break
            }
            if (callback === undefined) break;
        }
        callback.bind(this);
        callback(token);
    }
    
    call_cbf("%s");
'''

reCaptchaCallbackFunction1 = '''
    function call_cbf(token) {
        let widgetId = 0;
        let widget = ___grecaptcha_cfg.clients[widgetId];
        let callback = undefined;
        for (let k1 in widget) {
            let obj = widget[k1];
            if (typeof obj !== "object") continue;
            for (let k2 in obj) {
                if (obj[k2] === null) continue;
                if (typeof obj[k2] !== "object") continue;
                if (obj[k2].callback === undefined) continue;
                callback = obj[k2].callback;
                break
            }
            if (callback === undefined) break;
        }
        callback.bind(this);
        callback(token);
    }

    call_cbf("%s");
'''
