# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import configs
import csv


def santi(s):
    return str(s).strip().replace(' ', '').replace('\"', '').replace('\'', '').replace('[', '').replace(']', '')


def readAuthentications():
    authentications = []
    try:
        with open(configs.inputConfig['authentications']) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            i = 0
            for row in csv_reader:
                if i > 0:
                    if len(row) == 2:
                        authentications.append([row[0], row[1]])
                i += 1
    except:
        pass
    return authentications


def readAccounts_raw():
    accounts = []
    try:
        with open(configs.inputConfig['accounts']) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            i = 0
            for row in csv_reader:
                if i > 0:
                    if len(row) == 7:
                        accounts.append([row[0], row[1], row[2], row[3], row[4], row[5], row[6]])
                i += 1
    except:
        pass
    return accounts


def readAccounts():
    def tools(ts):
        r = []
        try:
            r = santi(ts).split('.')
            r = [x for x in r if x != '']
        except:
            pass
        return r

    accounts = []
    try:
        with open(configs.inputConfig['accounts']) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            i = 0
            for row in csv_reader:
                if i > 0:
                    if len(row) == 7:
                        for j in range(len(row)):
                            row[j] = santi(row[j])
                        if row[0] != '' and row[1] != '':
                            accounts.append({
                                'cookies': [
                                    {
                                        'name': 'token_id',
                                        'value': row[0],
                                        'domain': 'all-access.wax.io',
                                        'path': '/',
                                    },
                                    {
                                        'name': 'session_token',
                                        'value': row[1],
                                        'domain': '.wax.io',
                                        'path': '/',
                                    },
                                ],
                                'proxy': row[2],
                                'land': row[3],
                                'tools': tools(row[4]),
                                'username': row[5],
                                'account': row[6],
                            })
                i += 1
    except:
        pass
    return accounts


def writeInput(table, file, title=[]):
    try:
        f = open(configs.inputConfig[file], "w")
        if len(title) > 0:
            s_row = ','.join(title) + '\n'
            f.write(s_row)
        for row in table:
            s_row = ','.join(row) + '\n'
            f.write(s_row)
        f.close()
    except:
        pass
