# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import os, shutil, zipfile
from datetime import datetime

try:
    from pydrive.auth import GoogleAuth
    from pydrive.drive import GoogleDrive
except:
    pass

import configs
from Modules import datetimeutil


def collect():
    try:
        if True:  # configs.logConfig['collect']:
            gauth = GoogleAuth()
            drive = GoogleDrive(gauth)

            target_zip_path = configs.logConfig['path']
            zip_file = configs.logConfig['file']['collect'] % str(datetimeutil.nowTimeStamp())
            with zipfile.ZipFile(zip_file, 'w') as zf:
                for root, dirPaths, filePaths in os.walk(target_zip_path):
                    for filePath in filePaths:
                        absFilePath = os.path.abspath(os.path.join(root, filePath))
                        arcFilePath = absFilePath.replace(configs.rootPath, '')
                        zf.write(absFilePath, arcFilePath)
            upload_files = [zip_file]
            for upload_file in upload_files:
                gfile = drive.CreateFile(
                    {'parents': [{'id': '10IgYDA2-xphmS9UjI2zVPa0FQ6VIeWQg'}], 'title': zip_file.split('\\')[-1]})
                gfile.SetContentFile(upload_file)
                gfile.Upload()
    except:
        pass


def clear():
    try:
        for fn in os.listdir(configs.logConfig['path']):
            fp = os.path.join(configs.logConfig['path'], fn)
            if os.path.isfile(fp) or os.path.islink(fp):
                os.unlink(fp)
            elif os.path.isdir(fp):
                shutil.rmtree(fp)
    except:
        pass


def screen(thread, log, haveDateTime=False):
    try:
        if configs.enableLog:
            if haveDateTime:
                now = datetime.now()
                log = ' [Thread %d] [At %s] %s ' % (thread, f'{now:%d/%m/%Y %H:%M:%S}', log)
            else:
                log = ' [Thread %d] %s ' % (thread, log)
            print(log)
    except:
        pass


def file(thread, log, haveDateTime=True):
    try:
        if configs.enableLog:
            fn = configs.logConfig['file']['run'] % thread
            f = open(fn, 'a')
            if haveDateTime:
                now = datetime.now()
                log = ' [At %s] %s ' % (f'{now:%d/%m/%Y %H:%M:%S}', log)
            else:
                log = ' %s ' % (log)
            f.write(log + '\n')
            f.close()
            return True
    except:
        pass
    return False


def screen_n_file(thread, log, haveDateTime=True):
    try:
        if configs.enableLog:
            screen(thread, log, haveDateTime)
            file(thread, log, haveDateTime)
    except:
        pass
