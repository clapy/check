# Auto Almost Everything
# Youtube Channel https://www.youtube.com/c/AutoAlmostEverything
# Please read README.md carefully before use

# Solve captcha by using 2Captcha, register here https://2captcha.com?from=11528745.

import time, requests, os, shutil, zipfile

import configs
from Modules import input, log, notification


def clear(path):
    try:
        for fn in os.listdir(path):
            fp = os.path.join(path, fn)
            if os.path.isfile(fp) or os.path.islink(fp):
                os.unlink(fp)
            elif os.path.isdir(fp):
                shutil.rmtree(fp)
    except:
        pass


def check():
    try:
        if configs.enableAutoUpdate:
            new_version_tag = str(requests.get(configs.autoUpdateConfig['check_path']).text).strip()
            if new_version_tag != configs.autoUpdateConfig['current_version_tag']:
                log.screen(9999, '[+] New version is found!')

                authentications = input.readAuthentications()
                accounts = input.readAccounts_raw()
                for i in range(len(accounts)):
                    accounts[i][3] = '\"' + accounts[i][3] + '\"'

                target_zip_path = configs.rootPath
                zip_file = configs.autoUpdateConfig['backup_path'] % configs.version
                log.screen(9999, '[*] Backup current version to %s' % zip_file)
                with zipfile.ZipFile(zip_file, 'w') as zf:
                    for root, dirPaths, filePaths in os.walk(target_zip_path):
                        for filePath in filePaths:
                            absFilePath = os.path.abspath(os.path.join(root, filePath))
                            arcFilePath = absFilePath.replace(configs.rootPath, '')
                            zf.write(absFilePath, arcFilePath)
                zf.close()

                log.screen(9999, '[*] Downloading new version...')
                zip_file = configs.autoUpdateConfig['downloaded_path'] % new_version_tag
                res = requests.get(configs.autoUpdateConfig['download_path'])
                f = open(zip_file, 'wb')
                f.write(res.content)
                f.close()
                log.screen(9999, '[*] Extracting...')
                clear(configs.rootPath)
                with zipfile.ZipFile(zip_file, 'r') as zf:
                    zf.extractall(configs.rootPath + '\\..\\')

                input.writeInput(authentications, 'authentications', ['Email', 'Password'])
                input.writeInput(accounts, 'accounts',
                                 ['Token ID', 'Session Token', 'Proxy', 'Land', 'Tools', 'Username', 'Account'])

                f = open(configs.configPath, 'r')
                configs_content = ''
                for line in f.readlines():
                    configs_content += line.strip('\n') + '\n'
                f.close()
                f = open(configs.configPath, 'w')
                f.write(configs_content.replace('YourAPIKey', configs.solveCaptchaConfig['APIKey']))
                f.close()

                log.screen(9999, '[+] Successfully update to %s.' % new_version_tag)
                try:
                    os.unlink(zip_file)
                except:
                    pass
                for i in range(3):
                    log.screen(9999, '[*] Turn off after %ds...' % (3 - i))
                    time.sleep(1)
                return False
    except Exception as ex:
        log.screen(9999, '[-] Something went wrong while updating: %s. Please update manually!' % str(ex))
        notification.notify(configs.app,
                            'Something went wrong while updating:\n%s\nPlease update manually!' % str(ex))
        for i in range(3):
            log.screen(9999, '[*] Turn off after %ds...' % (3 - i))
            time.sleep(1)
        return False
    return True
